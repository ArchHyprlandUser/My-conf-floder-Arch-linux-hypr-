#!/bin/bash

# apps
sudo cp ~/.ml4w-hyprland/dotfiles/share/apps/com.ml4w.welcome /usr/bin
sudo cp ~/.ml4w-hyprland/dotfiles/share/apps/com.ml4w.dotfilessettings /usr/bin
sudo cp ~/.ml4w-hyprland/dotfiles/share/apps/com.ml4w.hyprland.settings /usr/bin
echo ":: Apps updated"
